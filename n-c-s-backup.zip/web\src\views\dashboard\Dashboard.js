import React from 'react'

const Dashboard = () => {
  return (
    <div style={{ textAlign: 'center', marginTop: '4rem' }}>
      <h1>Bienvenido a GTAHUB Planos Manager</h1>
      <p>Usa el menú lateral para navegar entre Localizaciones y Fabricaciones.</p>
    </div>
  )
}

export default Dashboard
