/* import { DatabaseManager } from '../src/database/DatabaseManager';

(async () => {
    const db = new DatabaseManager();
    await db.initialize();
    const actualizados = await db.actualizarTodasLasFotoURLs();
    console.log(`✅ URLs de fotos actualizadas: ${actualizados}`);
    await db.close();
})();
 */